/* RES Financial Model（general） —— 界面逻辑 */
"use strict";

const S = {
  schema: null,
  values: {},
  inputs: {},
  model: null,
  view: "overview",
  table: null,
  booted: false,
  waccLive: null,
  waccTouched: false,
  waccBusy: false,
  waccFetchedAt: 0,
  waccCheckedAt: 0,
  decEdits: {},
};

const ACCENTS = [
  ["#27ae60", "#1e8449"],
  ["#2980b9", "#21618c"],
  ["#d4a017", "#b8860b"],
  ["#16a085", "#0e6655"],
  ["#e67e22", "#ba6a12"],
  ["#607d8b", "#455a64"],
  ["#c0392b", "#96281b"],
  ["#8e44ad", "#6c3483"],
  ["#2e86c1", "#1f618d"],
  ["#5c6bc0", "#3949ab"],
  ["#00897b", "#00695c"],
  ["#7b8a2f", "#5d6922"],
];

const CAT_CLASS = { 收益: "yield", 偿债: "debt", 规模: "scale", 回报: "return" };

const $ = (id) => document.getElementById(id);
const api = () => window.pywebview.api;

/* ── 启动 ─────────────────────────────────────────────── */
function applyAppName(name) {
  if (!name) return;
  document.title = name;
  const h = $("app-title");
  if (h) h.textContent = name;
}

function boot() {
  if (S.booted) return;
  S.booted = true;
  api().schema().then((sc) => {
    S.schema = sc;
    applyAppName(sc.appName);
    buildPresets();
    buildGroups();
    buildTabs();
    setValues(sc.defaults);
    LicenseUI.init();
    compute();
    refreshWacc(false);                       // 先读快照/兜底，立即出数
    setTimeout(() => refreshWacc(true, true), 400);   // 再后台联网刷新
    setInterval(() => refreshWacc(true, true), 10 * 60 * 1000);   // 常驻：每 10 分钟联网取数
    window.addEventListener("online", () => refreshWacc(true, true));  // 网络恢复即取
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden && Date.now() - S.waccFetchedAt > STALE_MS) {
        refreshWacc(true, true);
      }
    });
  });
}

// 有网络就实时取数；超过该时长未取数即在下次窗口激活/重算时补取
const STALE_MS = 5 * 60 * 1000;

window.addEventListener("pywebviewready", boot);
window.addEventListener("DOMContentLoaded", () => {
  if (window.pywebview && window.pywebview.api) boot();
});

/* ── 左侧参数表 ───────────────────────────────────────── */
function enOf(s) {
  const m = S.schema.choicesEn || {};
  for (const k in m) {
    const i = (S.schema.choices[k] || []).indexOf(s);
    if (i >= 0 && m[k][i]) return m[k][i];
  }
  return "";
}

function biHtml(cn, en) {
  return cn + (en ? `<span class="en">${esc(en)}</span>` : "");
}

function buildPresets() {
  const box = $("presets");
  S.schema.scenarios.forEach((name, i) => {
    const b = document.createElement("button");
    b.innerHTML = biHtml(name, (S.schema.scenariosEn || [])[i] || "");
    b.dataset.scenario = name;
    if (i === 0) b.classList.add("active");
    b.addEventListener("click", () => loadPreset(name));
    box.appendChild(b);
  });
}

function syncPresetButtons(name) {
  document.querySelectorAll("#presets button").forEach((b) => {
    b.classList.toggle("active", b.dataset.scenario === name);
  });
}

/* 选择项：优先用后端提供的 fieldOptions（国别/行业/币种/Rd 方式） */
function fieldOptionsFor(key) {
  const fo = (S.schema.fieldOptions || {})[key];
  if (fo && fo.length) return fo;
  const options = (S.schema.choices || {})[key] || [];
  const optionsEn = (S.schema.choicesEn || {})[key] || [];
  return options.map((o, i) => ({ v: o, t: o, t_en: optionsEn[i] || "" }));
}

function fillSelect(el, list) {
  const cur = el.value || S.values[el.dataset.key] || "";
  el.innerHTML = "";
  list.forEach((o) => {
    const opt = document.createElement("option");
    opt.value = o.v;
    opt.textContent = o.t + (o.t_en ? " / " + o.t_en : "");
    el.appendChild(opt);
  });
  if (list.some((o) => o.v === cur)) el.value = cur;
  else if (list.length) el.value = list[0].v;
}

function applyFieldOptions(options) {
  Object.entries(options || {}).forEach(([key, list]) => {
    const el = S.inputs[key];
    if (!el || el.tagName !== "SELECT" || !list || !list.length) return;
    el.dataset.key = key;
    fillSelect(el, list);
    S.values[key] = el.value;
  });
  applyRules();
}

async function refreshFieldOptions(country) {
  try {
    const res = await api().field_options(country || S.values.wacc_country || "");
    if (res && res.ok) {
      applyFieldOptions(res.options);
      scheduleCompute();
    } else {
      scheduleCompute();
    }
  } catch (e) {
    scheduleCompute();
  }
}

function buildGroups() {
  const host = $("groups");
  S.schema.groups.forEach((g, gi) => {
    const [accent, accentD] = ACCENTS[gi % ACCENTS.length];
    const card = document.createElement("div");
    card.className = "group";
    card.style.setProperty("--accent", accent);
    card.style.setProperty("--accent-d", accentD);
    card.style.setProperty("--tint", accent + "12");

    const head = document.createElement("div");
    head.className = "group-head";
    head.innerHTML =
      `<span class="group-accent"></span>` +
      `<span class="group-num">${gi + 1}</span>` +
      `<span class="group-title">${biHtml(g.title, g.title_en)}</span>` +
      `<span class="group-chevron"></span>`;
    head.addEventListener("click", () => card.classList.toggle("collapsed"));
    card.appendChild(head);

    const body = document.createElement("div");
    body.className = "group-body";

    g.fields.forEach((f) => {
      const row = document.createElement("div");
      row.className = "field";
      row.dataset.key = f.key;
      row.dataset.label = (f.label + " " + f.label_en + " " + f.key).toLowerCase();

      const lab = document.createElement("label");
      lab.innerHTML = biHtml(f.label, f.label_en);
      lab.title = f.label + (f.label_en ? " / " + f.label_en : "");

      let el;
      if (f.kind === "choice") {
        el = document.createElement("select");
        el.dataset.key = f.key;
        fillSelect(el, fieldOptionsFor(f.key));
        el.addEventListener("change", () => {
          S.values[f.key] = el.value;
          if (f.key === "scenario") loadPreset(el.value);
          else if (f.key === "wacc_country") refreshFieldOptions(el.value);
          else {
            applyRules();
            scheduleCompute();
          }
        });
      } else {
        el = document.createElement("input");
        el.type = "text";
        el.spellcheck = false;
        el.autocomplete = "off";
        el.inputMode = f.kind === "text" ? "text" : "decimal";
        el.addEventListener("input", () => {
          S.values[f.key] = el.value;
          scheduleCompute();
        });
      }
      S.inputs[f.key] = el;

      const unit = document.createElement("span");
      unit.className = "unit";
      unit.textContent = f.unit || "";
      unit.title = f.unit || "";

      row.append(lab, el, unit);
      if (S.schema.notes && S.schema.notes[f.key]) {
        const note = document.createElement("div");
        note.className = "field-note hidden";
        note.dataset.noteKey = f.key;
        row.appendChild(note);
      }
      body.appendChild(row);
    });

    card.appendChild(body);
    host.appendChild(card);
  });

  $("param-search").addEventListener("input", (e) => {
    const q = e.target.value.trim().toLowerCase();
    document.querySelectorAll(".group").forEach((g) => {
      let any = false;
      g.querySelectorAll(".field").forEach((f) => {
        if (f.classList.contains("rule-hide")) return;
        const hit = !q || f.dataset.label.includes(q);
        f.classList.toggle("dim", !hit);
        if (hit) any = true;
      });
      g.classList.toggle("hidden", !any);
      if (q && any) g.classList.remove("collapsed");
    });
  });
}

/* ── 选项驱动的字段显隐与方法说明 ─────────────────────── */
function ruleVisible(key) {
  const rules = S.schema.rules || [];
  for (const r of rules) {
    if (r.key !== key) continue;
    const dv = S.values[r.driver];
    if (dv == null || !r.values.includes(String(dv))) return false;
  }
  return true;
}

function applyRules() {
  document.querySelectorAll(".field[data-key]").forEach((row) => {
    row.classList.toggle("rule-hide", !ruleVisible(row.dataset.key));
  });

  document.querySelectorAll(".group").forEach((g) => {
    const fields = g.querySelectorAll(".field[data-key]");
    const shown = Array.from(fields).filter((f) => !f.classList.contains("rule-hide"));
    g.classList.toggle("rule-hide", fields.length > 0 && shown.length === 0);
  });

  const notes = S.schema.notes || {};
  const notesEn = S.schema.notesEn || {};
  document.querySelectorAll(".field-note").forEach((el) => {
    const key = el.dataset.noteKey;
    const txt = notes[key] && notes[key][S.values[key]];
    const txtEn = notesEn[key] && notesEn[key][S.values[key]];
    el.innerHTML = txt
      ? esc(txt) + (txtEn ? `<span class="en">${esc(txtEn)}</span>` : "")
      : "";
    el.classList.toggle("hidden", !txt);
  });
}

function setValues(values) {
  Object.keys(S.values).forEach((k) => {
    if (!(k in values)) delete S.values[k];
  });
  Object.entries(values).forEach(([k, v]) => {
    S.values[k] = String(v);
    const el = S.inputs[k];
    if (el) el.value = v;
  });
  if (values.scenario) syncPresetButtons(values.scenario);
  if (S.schema) applyRules();
}

async function loadPreset(name) {
  const res = await api().preset(name);
  if (!res.ok) { toast(res.error, true); return; }
  S.decEdits = {};
  setValues(res.values);
  setStatus("已载入「" + name + "」情景 Preset loaded");
  compute();
}

/* ── 页签 ─────────────────────────────────────────────── */
function buildTabs() {
  const box = $("tabs");
  const tabs = [{ id: "overview", label: "概览", en: "Overview" }]
    .concat(S.schema.tables.map((t) => ({
      id: "table:" + t.name, label: t.name, en: t.name_en || "",
    })))
    .concat([{ id: "scenario", label: "情景对比", en: "Scenario Comparison" }]);

  tabs.forEach((t, i) => {
    const b = document.createElement("button");
    b.innerHTML = biHtml(t.label, t.en);
    b.dataset.tab = t.id;
    if (i === 0) b.classList.add("active");
    b.addEventListener("click", () => switchView(t.id));
    box.appendChild(b);
  });
}

function setTitle(cn, en) {
  $("view-title").innerHTML = biHtml(cn, en);
}

function switchView(id) {
  S.view = id;
  document.querySelectorAll("#tabs button").forEach((b) => {
    b.classList.toggle("active", b.dataset.tab === id);
  });
  $("view-overview").classList.toggle("hidden", id !== "overview");
  $("view-table").classList.toggle("hidden", !id.startsWith("table:"));
  $("view-scenario").classList.toggle("hidden", id !== "scenario");

  if (id === "overview") {
    setTitle("核心指标", "Key Metrics");
    if (S.model) renderCharts(S.model.chart);
  } else if (id.startsWith("table:")) {
    S.table = id.slice(6);
    const t = S.schema.tables.find((x) => x.name === S.table);
    setTitle(S.table, (t && t.name_en) || "");
    if (S.model) renderTable(S.table);
  } else {
    setTitle("情景对比", "Scenario Comparison");
    runScenarios();
  }
}

/* ── 计算 ─────────────────────────────────────────────── */
let timer = null;
let seq = 0;

function scheduleCompute() {
  clearTimeout(timer);
  timer = setTimeout(compute, 320);
}

async function compute() {
  clearTimeout(timer);
  const my = ++seq;
  setStatus("计算中… Computing", "busy");
  try {
    const res = await api().compute({ ...S.values });
    if (my !== seq) return;
    if (!res.ok) {
      if (res.gated) {
        LicenseUI.showGate(res.license);
        setStatus("需要授权 License required", "err");
        return;
      }
      setStatus("计算失败 Failed", "err");
      toast(res.error, true);
      return;
    }
    S.model = res;
    render(res);
    setStatus(`已更新 Updated · ${res.elapsed}s`);
    // 网络可用时按需补取实时数（限频，避免逐键刷新）
    if (navigator.onLine !== false &&
        Date.now() - S.waccCheckedAt > 2 * 60 * 1000) {
      refreshWacc(true, true);
    }
  } catch (e) {
    if (my !== seq) return;
    setStatus("计算失败 Failed", "err");
    toast(String(e), true);
  }
}

function render(res) {
  renderMeta(res.summary);
  renderCards(res.cards);
  renderCharts(res.chart);
  renderFirstYear(res.firstYear);
  if (S.waccLive) renderWaccChip(S.waccLive);
  if (S.view.startsWith("table:")) renderTable(S.table);
  if (S.view === "scenario") runScenarios();
}

function renderMeta(s) {
  $("meta-line").innerHTML =
    `<span class="chip">建设期 Construction <b>${s.construct}</b> 年 yrs</span>` +
    `<span class="chip">运营期 Operation <b>${s.operate}</b> 年 yrs</span>` +
    `<span class="chip">总投资 Investment <b>${fmt(s.investment, 0)}</b> 万元</span>` +
    `<span class="chip">权益 Equity <b>${fmt(s.equity, 0)}</b> 万元</span>` +
    `<span class="chip">债务 Debt <b>${fmt(s.debt, 0)}</b> 万元</span>` +
    `<span class="chip">WACC <b>${(s.wacc * 100).toFixed(2)}%</b></span>`;
}

function renderCards(cards) {
  const host = $("cards");
  host.innerHTML = "";
  cards.forEach((c) => {
    const div = document.createElement("div");
    div.className = "metric-card cat-" + (CAT_CLASS[c.cat] || "yield");
    const unit = c.kind === "pct" ? "" : (c.unit || "");
    div.innerHTML =
      `<div class="metric-top"><span class="metric-label">` +
      `${biHtml(c.label, c.label_en)}</span>` +
      `<span class="metric-tag">${biHtml(c.cat, c.cat_en)}</span></div>` +
      `<div class="metric-value">${c.text}` +
      (unit ? `<span class="metric-unit">${unit}</span>` : "") +
      `</div>`;
    const v = div.querySelector(".metric-value");
    if (c.text.length > 10) v.style.fontSize = "18px";
    else if (c.text.length > 8) v.style.fontSize = "20px";
    host.appendChild(div);
  });
}

function renderFirstYear(items) {
  const host = $("first-year");
  host.innerHTML = items
    .map((it) => `<div class="fy-item"><span class="l">` +
                 `${biHtml(it.label, it.label_en)}</span>` +
                 `<span class="v">${fmt(it.value, 1)}</span></div>`)
    .join("");
}

/* ── 表格 ─────────────────────────────────────────────── */
const esc = (s) => String(s).replace(/[&<>"]/g,
  (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

function tableHead(cols, colsEn) {
  return "<thead><tr>" + cols.map((c, i) =>
    `<th>${biHtml(c, (colsEn || [])[i] || "")}</th>`).join("") +
    "</tr></thead><tbody>";
}

function seriesHtml(t, idx) {
  let html = "<thead><tr>" +
    idx.map((i) => `<th>${biHtml(t.cols[i], (t.cols_en || [])[i] || "")}</th>`)
      .join("") +
    "</tr></thead><tbody>";
  t.rows.forEach((row) => {
    const cls = row.k === 0 ? ' class="constr"' : "";
    html += `<tr${cls}>` + idx.map((i) => {
      const cell = row.cells[i];
      const kind = t.kinds[i];
      let extra = "";
      if (kind !== "int" && kind !== "op") {
        if (String(cell).startsWith("-")) extra = ' class="neg"';
        if (t.cols[i] === "DSCR" && parseFloat(cell) < 1.2)
          extra = ' class="neg dscr-low"';
      }
      return `<td${extra}>${esc(cell)}</td>`;
    }).join("") + "</tr>";
  });
  return html + "</tbody>";
}

function renderSeriesTable(t) {
  return seriesHtml(t, t.cols.map((_, i) => i));
}

// 列放不下一屏时，按列切块、每块重复前两列（项目年/运营年），纵向排列
function layoutTableBlocks(t, table) {
  const wrap = table.parentElement;
  const avail = wrap.clientWidth - 20;
  if (!avail || avail < 240) return;
  const ths = table.querySelectorAll("thead th");
  if (ths.length < 4) return;
  const w = [...ths].map((th) => th.getBoundingClientRect().width);
  const keyW = w[0] + w[1];
  const groups = [];
  let cur = [], used = keyW;
  for (let i = 2; i < t.cols.length; i++) {
    const cw = w[i] + 10;
    if (cur.length && used + cw > avail) {
      groups.push(cur); cur = []; used = keyW;
    }
    cur.push(i); used += cw;
  }
  if (cur.length) groups.push(cur);
  if (groups.length < 2) return;

  wrap.innerHTML = "";
  groups.forEach((g, gi) => {
    const el = document.createElement("table");
    el.className = "data-table series-table table-block";
    if (gi === 0) el.id = "data-table";
    el.innerHTML = seriesHtml(t, [0, 1].concat(g));
    wrap.appendChild(el);
  });
}

const DEC_COLS8 = '<colgroup>' + '<col style="width:12.5%">'.repeat(8) +
  '</colgroup>';
const DEC_COLS6 = '<colgroup><col style="width:5%"><col style="width:30%">' +
  '<col style="width:14%"><col style="width:27%"><col style="width:12%">' +
  '<col style="width:12%"></colgroup>';

function renderDecisionTable(t) {
  return (t.blocks || []).map((block, bi) => {
    let html = `<table class="data-table dec-table">${bi === 0 ? DEC_COLS8 : DEC_COLS6}<tbody>`;
    block.forEach((row) => {
      const cls = row.cls ? ` class="${row.cls}"` : "";
      const meta = (row.sec
        ? ` data-sec="${row.sec}" data-key="${row.key}"` +
          ` data-unit="${row.unit || "W"}" data-param="${row.param || ""}"`
        : "") + (row.role ? ` data-row-role="${row.role}"` : "");
      html += `<tr${cls}${meta}>` + row.cells.map((cell) => {
        const span = cell.span > 1 ? ` colspan="${cell.span}"` : "";
        let sty = "";
        if (cell.align) sty += `text-align:${cell.align};`;
        if (cell.pad) sty += `padding-right:${cell.pad};`;
        const align = sty ? ` style="${sty}"` : "";
        let inner;
        if (cell.input === "num") {
          inner = `<input type="number" step="0.0001" class="dec-inp num"` +
                  ` data-role="price" value="${esc(cell.value ?? "")}">`;
        } else if (cell.input === "text") {
          const role = cell.span > 1 ? "note" : "desc";
          inner = `<input type="text" class="dec-inp txt"` +
                  ` data-role="${role}" value="${esc(cell.value ?? "")}">`;
        } else if (cell.amount) {
          inner = `<span class="dec-amt">${esc(cell.t)}</span>`;
        } else if (cell.bal) {
          inner = `<strong>= <span class="dec-bal" data-bal="${cell.bal}">` +
                  `${esc(cell.t)}</span></strong>`;
        } else if (cell.sub) {
          inner = `<strong><span class="dec-sub" data-sub="${cell.sub}">` +
                  `${esc(cell.t)}</span></strong>`;
        } else {
          const tag = cell.strong ? "strong" : "span";
          inner = `<${tag}>${esc(cell.t)}</${tag}>`;
        }
        return `<td${span}${align}>${inner}</td>`;
      }).join("") + "</tr>";
    });
    return html + "</tbody></table>";
  }).join("");
}

/* 决策表：内容/单价/备注可改；金额与三行结余随输入实时重算 */
function decisionCtx(t) {
  S.decDC = Number(t.dc_mw) || 0;
  S.decMwh = Number(t.storage_mwh) || 0;
  S.decTI = Number(t.total_inv) || 0;
}

function decisionEdit(key) {
  return S.decEdits[key] || (S.decEdits[key] = {});
}

function applyDecisionEdits() {
  document.querySelectorAll("#table-wrap tr[data-sec]").forEach((tr) => {
    const ed = S.decEdits[tr.dataset.key];
    if (!ed) return;
    tr.querySelectorAll("input.dec-inp").forEach((el) => {
      const v = ed[el.dataset.role];
      if (v != null) el.value = v;
    });
  });
}

function decRecalc() {
  const dc = S.decDC || 0;
  const mwh = S.decMwh || 0;
  const sums = { 2: 0, 3: 0, 4: 0 };
  let adjTr = null;
  document.querySelectorAll("#table-wrap tr[data-sec]").forEach((tr) => {
    if (tr.dataset.rowRole === "adj") { adjTr = tr; return; }
    const sec = Number(tr.dataset.sec);
    const inp = tr.querySelector("input.dec-inp.num");
    const price = inp ? parseFloat(inp.value) : 0;
    const mult = tr.dataset.unit === "Wh" ? mwh * 100 : dc * 100;
    const amt = (isFinite(price) ? price : 0) * mult;
    const span = tr.querySelector(".dec-amt");
    if (span) span.textContent = Math.abs(amt) < 0.05 ? "—" : fmt(amt, 1);
    if (sums[sec] != null) sums[sec] += amt;
  });
  const ti = S.decTI || 0;
  const b2 = ti - sums[2] - sums[3];
  let sec4 = sums[4];
  if (adjTr) {
    // 其他 Others：金额 = 第 3 项结余 − 第 4 项其余各项之和；单价按总直流容量反推
    const adjAmt = b2 - sec4;
    const adjInp = adjTr.querySelector("input.dec-inp.num");
    const adjSpan = adjTr.querySelector(".dec-amt");
    if (adjInp) {
      const mult = adjTr.dataset.unit === "Wh" ? mwh * 100 : dc * 100;
      adjInp.value = (mult ? adjAmt / mult : 0).toFixed(4);
      adjInp.readOnly = true;
      adjInp.title = "按第 3 项结余反推 Back-solved from balance";
      adjInp.style.background = "#eef3f7";
      adjInp.style.color = "#1f5051";
    }
    if (adjSpan) adjSpan.textContent = fmt(adjAmt, 1);
    sec4 += adjAmt;
  }
  const subs = { s1: ti, s2: sums[2], s3: sums[3], s4: sec4 };
  Object.entries(subs).forEach(([k, v]) => {
    const el = document.querySelector(`.dec-sub[data-sub="${k}"]`);
    if (el) el.textContent = fmt(v, 1);
  });
  const bal = {
    b1: ti - sums[2],
    b2: b2,
    b3: ti - sums[2] - sums[3] - sec4,
  };
  Object.entries(bal).forEach(([k, v]) => {
    const el = document.querySelector(`.dec-bal[data-bal="${k}"]`);
    if (!el) return;
    // 末行结余恒为 0 并显示出来
    if (k === "b3") { el.textContent = fmt(0, 1); return; }
    el.textContent = Math.abs(v) < 0.05 ? "—" : fmt(v, 1);
  });
  const b3tr = document.querySelector('.dec-bal[data-bal="b3"]');
  const last = b3tr && b3tr.closest("tr") && b3tr.closest("tr").lastElementChild;
  if (last && last.textContent.indexOf("EPC") >= 0 && dc) {
    last.textContent = `EPC 造价 Price ${fmt(sec4 / (dc * 100), 2)} 元/W`;
  }
}

function onDecisionEdit(e) {
  const el = e.target;
  if (!el.classList || !el.classList.contains("dec-inp")) return;
  const tr = el.closest("tr[data-sec]");
  if (!tr) return;
  const role = el.dataset.role;
  const param = tr.dataset.param;
  // 对应模型参数的单价由重算回填，不本地暂存，避免参数变动后旧值残留
  if (!(role === "price" && param)) {
    decisionEdit(tr.dataset.key)[role] = el.value;
  }
  decRecalc();
  if (e.type === "change" && role === "price" && param) {
    const v = parseFloat(el.value);
    if (!isFinite(v)) return;
    S.values[param] = String(v);
    if (S.inputs[param]) S.inputs[param].value = String(v);
    scheduleCompute();
  }
}

function wireDecisionTable(t) {
  decisionCtx(t);
  const wrap = $("table-wrap");
  if (wrap.dataset.decWired !== "1") {
    wrap.dataset.decWired = "1";
    wrap.addEventListener("input", onDecisionEdit);
    wrap.addEventListener("change", onDecisionEdit);
  }
  applyDecisionEdits();
  decRecalc();
}

function renderDefTable(t) {
  let html = tableHead(t.cols, t.cols_en);
  t.rows.forEach((row) => {
    const cls = row.cls ? ` class="${row.cls}"` : "";
    html += `<tr${cls}>` + row.cells.map((cell, i) => {
      const neg = i === 1 && /^-/.test(String(cell)) ? ' class="neg"' : "";
      return `<td${neg}>${esc(cell)}</td>`;
    }).join("") + "</tr>";
  });
  return html + "</tbody>";
}

function renderMatrixTable(t) {
  const base = typeof t.base === "number" ? t.base : t.cols.indexOf("基准");
  let html = "<thead><tr>" + t.cols.map((c, i) =>
    `<th${i === base ? ' class="base"' : ""}>` +
    `${biHtml(c, (t.cols_en || [])[i] || "")}</th>`).join("") +
    "</tr></thead><tbody>";
  t.rows.forEach((row) => {
    html += "<tr>" + row.cells.map((cell, i) => {
      const neg = i > 0 && /^-/.test(String(cell)) ? " neg" : "";
      const baseCls = i === base ? " base" : "";
      return `<td class="${(neg + baseCls).trim()}">${esc(cell)}</td>`;
    }).join("") + "</tr>";
  });
  return html + "</tbody>";
}

function renderTable(name) {
  const t = S.model.tables[name];
  if (!t) return;
  const title = t.title || name;
  const titleEn = t.title_en || t.name_en || "";
  $("table-title").innerHTML = biHtml(title, titleEn);
  setTitle(title, titleEn);

  const hint = $("table-hint");
  const foot = $("table-foot");
  const wrap = $("table-wrap");
  wrap.innerHTML = '<table class="data-table" id="data-table"></table>';
  const table = $("data-table");
  table.className = "data-table";
  foot.classList.add("hidden");
  foot.textContent = "";

  let html;
  if (t.type === "decision") {
    hint.innerHTML = biHtml(
      "网页同款格式 · 单位：万元 · 末项「其他」按第 3 项结余反推使结余为 0",
      "Web-model layout · 10K CNY · “Others” back-solved from balance");
    wrap.innerHTML = renderDecisionTable(t);
    wireDecisionTable(t);
    if (t.footer) {
      foot.textContent = t.footer;
      foot.classList.remove("hidden");
    }
    return;
  } else if (t.type === "combo") {
    hint.innerHTML = biHtml(
      "计算过程 · 三币种对比 · 敏感度（同页依次排列）",
      "Calculation steps · currency comparison · sensitivity (top to bottom)");
    wrap.innerHTML = (t.sections || []).map((s) => {
      const cls = s.type === "matrix"
        ? "data-table matrix-table" : "data-table def-table";
      const body = s.type === "matrix" ? renderMatrixTable(s) : renderDefTable(s);
      return `<div class="combo-sec">` +
        `<div class="combo-title">${biHtml(s.title || "", s.title_en || "")}</div>` +
        `<table class="${cls}">${body}</table>` +
        (s.footer ? `<div class="combo-foot">${esc(s.footer)}</div>` : "") +
        `</div>`;
    }).join("");
    if (t.footer) {
      foot.textContent = t.footer;
      foot.classList.remove("hidden");
    }
    return;
  } else if (t.type === "matrix") {
    table.classList.add("matrix-table");
    hint.innerHTML = biHtml(
      "行＝债务成本 Rd，列＝国别风险溢价 CRP · ★ 为当前口径",
      "Rows = cost of debt Rd, cols = country risk premium CRP · ★ current case");
    html = renderMatrixTable(t);
  } else if (t.type === "def") {
    table.classList.add("def-table");
    hint.innerHTML = biHtml(
      "计算过程表 · 数值随左侧参数实时重算",
      "Calculation table · recalculated live from sidebar inputs");
    html = renderDefTable(t);
  } else {
    table.classList.add("series-table");
    hint.innerHTML = biHtml(
      "单位：万元 · 建设期行以浅蓝底标示",
      "Unit: 10K CNY · Construction-period rows shaded blue");
    html = renderSeriesTable(t);
  }

  table.innerHTML = html;
  if (t.type !== "decision" && t.type !== "def" && t.type !== "matrix")
    layoutTableBlocks(t, table);
  if (t.footer) {
    foot.textContent = t.footer;
    foot.classList.remove("hidden");
  }
}

function runScenarios() {
  api().scenarios({ ...S.values }).then((res) => {
    if (!res.ok) { toast(res.error, true); return; }
    const cols = ["情景", "全投资 IRR", "资本金 IRR", "全投资 NPV",
                  "资本金 NPV", "LCOE", "最小 DSCR", "回收期"];
    const colsEn = ["Scenario", "Project IRR", "Equity IRR", "Project NPV",
                    "Equity NPV", "LCOE", "Min DSCR", "Payback"];
    let html = "<thead><tr>" + cols.map((c, i) =>
      `<th>${biHtml(c, colsEn[i])}</th>`).join("") +
      "</tr></thead><tbody>";
    res.rows.forEach((r, i) => {
      const cls = i === 0 ? ' class="constr"' : "";
      html += `<tr${cls}>` +
        `<td><b>${biHtml(r.name, r.name_en)}</b></td>` +
        `<td>${r.pirr}</td><td>${r.eirr}</td>` +
        `<td>${r.npv}</td><td>${r.enpv}</td>` +
        `<td>${r.lcoe}</td><td>${r.dscr}</td><td>${r.payback}</td></tr>`;
    });
    $("scen-table").innerHTML = html + "</tbody>";
  });
}

/* ── 图表 ─────────────────────────────────────────────── */
const NS = "http://www.w3.org/2000/svg";

function svgEl(tag, attrs, text) {
  const e = document.createElementNS(NS, tag);
  if (attrs) Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v));
  if (text != null) e.textContent = text;
  return e;
}

function fmtNum(v) {
  const a = Math.abs(v);
  if (a >= 10000) return (v / 10000).toFixed(a >= 100000 ? 0 : 1) + "亿";
  return Math.round(v).toLocaleString("zh-CN");
}

function fmt(v, nd) {
  if (v == null || !isFinite(v)) return "—";
  return v.toLocaleString("zh-CN", {
    minimumFractionDigits: nd,
    maximumFractionDigits: nd,
  });
}

function makeChart(host, opts) {
  host.innerHTML = "";
  const W = Math.max(380, host.clientWidth || 520);
  const H = Math.round(W * 0.37);
  const P = { l: 56, r: 12, t: 14, b: 26 };
  const labels = opts.labels;
  const n = labels.length;
  const stepX = n > 1 ? (W - P.l - P.r) / (n - 1) : 0;
  const xAt = (i) => P.l + (n > 1 ? stepX * i : (W - P.l - P.r) / 2);

  let vals = [0];
  opts.series.forEach((s) => s.values.forEach((v) => { if (v != null) vals.push(v); }));
  let lo = Math.min(...vals), hi = Math.max(...vals);
  if (lo === hi) { lo -= 1; hi += 1; }
  const pad = (hi - lo) * 0.08;
  lo -= pad; hi += pad;
  const yAt = (v) => P.t + (H - P.t - P.b) * (1 - (v - lo) / (hi - lo));

  const svg = svgEl("svg", {
    viewBox: `0 0 ${W} ${H}`,
    role: "img",
  });

  const defs = svgEl("defs");
  const grad = svgEl("linearGradient", { id: "areaGreen", x1: "0", y1: "0", x2: "0", y2: "1" });
  grad.append(
    svgEl("stop", { offset: "0%", "stop-color": "#27ae60", "stop-opacity": "0.18" }),
    svgEl("stop", { offset: "100%", "stop-color": "#27ae60", "stop-opacity": "0" }),
  );
  defs.appendChild(grad);
  svg.appendChild(defs);

  // 建设期底色
  if (opts.shadeUntil > 0) {
    const x0 = P.l - stepX / 2;
    const x1 = xAt(Math.min(opts.shadeUntil - 1, n - 1)) + stepX / 2;
    svg.appendChild(svgEl("rect", {
      x: Math.max(P.l - stepX / 2, x0), y: P.t,
      width: Math.max(0, x1 - x0), height: H - P.t - P.b,
      fill: "#eef4fa",
    }));
    svg.appendChild(svgEl("text", {
      x: Math.max(P.l, x0) + 5, y: P.t + 12,
      "font-size": "10.5", fill: "#30353a",
    }, "建设期 Construction"));
  }

  // 网格与 Y 轴
  const ticks = 4;
  for (let i = 0; i <= ticks; i++) {
    const v = lo + (hi - lo) * (i / ticks);
    const y = yAt(v);
    svg.appendChild(svgEl("line", {
      x1: P.l, y1: y, x2: W - P.r, y2: y,
      stroke: "#e8eef5", "stroke-width": "1",
    }));
    svg.appendChild(svgEl("text", {
      x: P.l - 8, y: y + 3.5, "text-anchor": "end",
      "font-size": "10.5", fill: "#2c3136",
    }, fmtNum(v)));
  }
  // 零轴
  if (lo < 0 && hi > 0) {
    svg.appendChild(svgEl("line", {
      x1: P.l, y1: yAt(0), x2: W - P.r, y2: yAt(0),
      stroke: "#c9d6e3", "stroke-dasharray": "3 3",
    }));
  }

  // X 轴标签
  const every = Math.max(1, Math.ceil(n / 8));
  const lastTick = Math.floor((n - 1) / every) * every;
  const showLast = n - 1 - lastTick >= Math.max(2, every * 0.6);
  labels.forEach((lab, i) => {
    if (i % every !== 0 && !(i === n - 1 && showLast)) return;
    svg.appendChild(svgEl("text", {
      x: xAt(i), y: H - 8, "text-anchor": "middle",
      "font-size": "10.5", fill: "#2c3136",
    }, String(lab)));
  });

  // 面积（第一条线）
  if (opts.series[0] && opts.series[0].fill !== false) {
    const s = opts.series[0];
    let d = `M ${xAt(0)} ${yAt(0)}`;
    s.values.forEach((v, i) => { d += ` L ${xAt(i)} ${yAt(v)}`; });
    d += ` L ${xAt(n - 1)} ${yAt(0)} Z`;
    svg.appendChild(svgEl("path", { d, fill: "url(#areaGreen)" }));
  }

  // 折线
  opts.series.forEach((s) => {
    let d = "";
    s.values.forEach((v, i) => {
      d += (i === 0 ? "M " : " L ") + xAt(i) + " " + yAt(v);
    });
    svg.appendChild(svgEl("path", {
      d, fill: "none", stroke: s.color, "stroke-width": "2",
      "stroke-linejoin": "round", "stroke-linecap": "round",
      "stroke-dasharray": s.dashed ? "5 3" : "none",
    }));
    s.values.forEach((v, i) => {
      const c = svgEl("circle", {
        cx: xAt(i), cy: yAt(v), r: "2.4",
        fill: "#fff", stroke: s.color, "stroke-width": "1.6",
      });
      c.appendChild(svgEl("title", {}, `第 ${labels[i]} 年 Year ${labels[i]} · ${s.name}：${fmt(v, 1)} 万元`));
      svg.appendChild(c);
    });
  });

  host.appendChild(svg);
}

function makeBarChart(host, opts) {
  host.innerHTML = "";
  const W = Math.max(380, host.clientWidth || 520);
  const H = Math.round(W * 0.37);
  const P = { l: 56, r: 12, t: 14, b: 26 };
  const n = opts.labels.length;

  const vals = [0];
  opts.series.forEach((s) => s.values.forEach((v) => { if (v != null) vals.push(v); }));
  let hi = Math.max(...vals) * 1.06;
  const lo = 0;
  const yAt = (v) => P.t + (H - P.t - P.b) * (1 - (v - lo) / (hi - lo));
  const groupW = (W - P.l - P.r) / n;
  const barW = Math.max(2, groupW * 0.32);

  const svg = svgEl("svg", { viewBox: `0 0 ${W} ${H}` });

  if (opts.shadeUntil > 0) {
    svg.appendChild(svgEl("rect", {
      x: P.l, y: P.t, width: groupW * opts.shadeUntil,
      height: H - P.t - P.b, fill: "#eef4fa",
    }));
  }

  const ticks = 4;
  for (let i = 0; i <= ticks; i++) {
    const v = hi * (i / ticks);
    const y = yAt(v);
    svg.appendChild(svgEl("line", {
      x1: P.l, y1: y, x2: W - P.r, y2: y,
      stroke: "#e8eef5", "stroke-width": "1",
    }));
    svg.appendChild(svgEl("text", {
      x: P.l - 8, y: y + 3.5, "text-anchor": "end",
      "font-size": "10.5", fill: "#2c3136",
    }, fmtNum(v)));
  }

  const every = Math.max(1, Math.ceil(n / 8));
  const lastTick = Math.floor((n - 1) / every) * every;
  const showLast = n - 1 - lastTick >= Math.max(2, every * 0.6);
  opts.labels.forEach((lab, i) => {
    if (i % every !== 0 && !(i === n - 1 && showLast)) return;
    const x = P.l + groupW * (i + 0.5);
    svg.appendChild(svgEl("text", {
      x, y: H - 8, "text-anchor": "middle",
      "font-size": "10.5", fill: "#2c3136",
    }, String(lab)));
  });

  opts.labels.forEach((lab, i) => {
    const cx = P.l + groupW * (i + 0.5);
    opts.series.forEach((s, si) => {
      const v = s.values[i] || 0;
      const off = (si - (opts.series.length - 1) / 2) * (barW + 1.5);
      const x = cx + off - barW / 2;
      const y = yAt(Math.max(0, v));
      const h = Math.max(1, yAt(0) - y);
      const r = svgEl("rect", {
        x, y, width: barW, height: h, rx: "1.6", fill: s.color, opacity: "0.92",
      });
      r.appendChild(svgEl("title", {}, `第 ${lab} 年 Year ${lab} · ${s.name}：${fmt(v, 1)} 万元`));
      svg.appendChild(r);
    });
  });

  host.appendChild(svg);
}

function renderCharts(c) {
  makeChart($("chart-cum"), {
    labels: c.yr,
    shadeUntil: c.t,
    series: [
      { name: "全投资 Project", color: "#27ae60", values: c.cum_p },
      { name: "资本金 Equity", color: "#2980b9", values: c.cum_e, dashed: true, fill: false },
    ],
  });
  makeBarChart($("chart-flow"), {
    labels: c.yr,
    shadeUntil: c.t,
    series: [
      { name: "营业收入 Revenue", color: "#27ae60", values: c.revenue },
      { name: "经营成本 OpEx", color: "#e67e22", values: c.opex },
    ],
  });
}

/* ── WACC 联网数据 ────────────────────────────────────── */
function renderWaccChip(res) {
  const chip = $("wacc-chip");
  const txt = $("wacc-chip-text");
  if (!chip || !txt) return;
  const info = (S.model && S.model.waccInfo) || null;
  if (!res || !res.ok) {
    chip.className = "wacc-chip offline";
    txt.textContent = info
      ? `WACC ${(info.wacc * 100).toFixed(2)}%` : "WACC 离线 Offline";
    chip.title = "未能读取 WACC 数据 Unable to read WACC data";
    return;
  }
  const kind = res.source === "live" ? "live"
             : res.source === "cache" ? "cache" : "offline";
  chip.className = "wacc-chip " + kind;
  txt.textContent = info
    ? `WACC ${(info.wacc * 100).toFixed(2)}% · ` +
      (kind === "live" ? "实时 Live" : kind === "cache" ? "快照 Snapshot" : "基准 Base")
    : (kind === "live" ? "WACC 实时 Live"
       : kind === "cache" ? "WACC 快照 Snapshot" : "WACC 基准 Base");
  chip.title = [
    "来源 Source：" + (kind === "live" ? "联网实时 Live" : kind === "cache" ? "本地快照 Snapshot" : "内置兜底 Fallback"),
    info ? `国别 ${info.country} · 行业 ${info.sector}` : "",
    info ? `币种 ${info.ccy} · Rf ${(info.rf * 100).toFixed(3)}%` : "",
    info ? `βu ${info.betaU.toFixed(4)} · ERP ${(info.erp * 100).toFixed(2)}%` : "",
    info ? `CRP ${(info.crp * 100).toFixed(2)}% · 违约利差 ${(info.cds * 100).toFixed(2)}%` : "",
    info ? `信用利差 ${(info.creditSpread * 100).toFixed(2)}% · Rd ${(info.rd * 100).toFixed(2)}%` : "",
    res.asof ? `数据日期 ${res.asof}` : "",
    res.fetched_at ? `抓取时间 ${res.fetched_at}` : "",
    res.error ? `提示：${res.error}` : "",
  ].filter(Boolean).join("\n");
}

async function refreshWacc(force, auto) {
  if (S.waccBusy) return;                 // 上一次联网尚未返回，避免叠加
  S.waccBusy = true;
  if (force) S.waccCheckedAt = Date.now();
  if (force && !auto) setStatus("联网刷新 WACC…", "busy");
  try {
    const res = await api().wacc_data(!!force);
    S.waccLive = res;
    if (force && res && res.ok && res.source === "live") {
      S.waccFetchedAt = Date.now();
    }
    if (force && res && res.ok) {
      await refreshFieldOptions();
      if (S.model) compute();
    }
    renderWaccChip(res);
    if (force && !auto) {
      if (res && res.ok) {
        setStatus("WACC 已刷新");
        toast("WACC 数据已更新，模型已按所选币种口径重算");
      } else {
        setStatus("WACC 刷新失败", "err");
        toast("WACC 联网刷新失败，继续使用现有数据", true);
      }
    }
  } catch (e) {
    renderWaccChip(null);
    if (!auto) {
      setStatus("WACC 刷新失败", "err");
      toast("WACC 获取失败：" + e, true);
    }
  } finally {
    S.waccBusy = false;
  }
}

/* ── 导出 / 状态 / 提示 ───────────────────────────────── */
async function doExport() {
  setStatus("导出中…", "busy");
  try {
    const res = await api().export();
    if (res.gated) { LicenseUI.showGate(res.license); return; }
    if (res.ok) {
      setStatus("导出完成");
      toast("已导出：" + res.path);
    } else if (res.cancelled) {
      setStatus("已取消导出");
    } else {
      setStatus("导出失败", "err");
      toast(res.error, true);
    }
  } catch (e) {
    setStatus("导出失败", "err");
    toast(String(e), true);
  }
}

function setStatus(msg, kind) {
  const el = $("status");
  el.className = "status" + (kind ? " " + kind : "");
  el.innerHTML = "<i></i>" + msg;
}

let toastTimer = null;
function toast(msg, isErr) {
  const el = $("toast");
  el.textContent = msg;
  el.className = "toast show" + (isErr ? " error" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.className = "toast"; }, 3600);
}

/* ── 事件绑定 ─────────────────────────────────────────── */
document.addEventListener("DOMContentLoaded", () => {
  $("btn-calc").addEventListener("click", compute);
  $("btn-export").addEventListener("click", doExport);
  $("btn-reset").addEventListener("click", async () => {
    const res = await api().defaults();
    S.decEdits = {};
    setValues(res.values);
    compute();
  });
  $("btn-scen").addEventListener("click", runScenarios);
  $("btn-wacc").addEventListener("click", () => refreshWacc(true, false));

  window.addEventListener("keydown", (e) => {
    if (!e.metaKey) return;
    if (e.key === "r") { e.preventDefault(); compute(); }
    if (e.key === "s") { e.preventDefault(); doExport(); }
  });

  let rz = null;
  window.addEventListener("resize", () => {
    clearTimeout(rz);
    rz = setTimeout(() => {
      if (!S.model) return;
      if (S.view === "overview") renderCharts(S.model.chart);
      else if (S.view.startsWith("table:")) renderTable(S.table);
    }, 180);
  });
});

window.__rneCompute = compute;
